
angular.module('shack').constant('configuration', {
    siteName: 'Shack',
    // facebookApiToken: '1406544132926146',
    // mixpanelApiToken: 'af496858fbad6db085f002140fd3c9e1',
    restBaseUrl: 'http://localhost:8080/shacksecu/api/',
    // websocketBaseUrl: 'http://dev.bearchoke.com:8080/ws',
    // webservicesBaseUrl: 'http://dev.bearchoke.com:8080/services',
    // frontendUrl: 'http://dev.bearchoke.com:8000',
    version: 'application/shack01'
    // mailchimpUsername: 'cfapps',
    // mailchimpU: '6e09b949dd8c5be5b4befdfeb',
    // mailchimpDc: 'us9',
    // mailchimpId: '670f539e60'
});
